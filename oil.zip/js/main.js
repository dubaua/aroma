import 'normalize.css';
import '../styles/main.scss';
import './pumpjack.js';
import './menu.js';
