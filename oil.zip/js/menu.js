import Immerser from 'immerser';

const immerserInstance = new Immerser({
  solidClassnameArray: [
    {},
    {
      menu: 'menu--contrast',
      contact: 'contact--contrast',
      pager: 'pager--contrast',
      language: 'language--contrast',
      about: 'about--contrast',
    },
    {},
    {
      menu: 'menu--contrast',
      pager: 'pager--contrast',
      about: 'about--contrast',
    },
    {},
    {},
    {
      // menu: 'menu--contrast',
      // contact: 'contact--contrast',
      // pager: 'pager--contrast',
      // language: 'language--contrast',
      // about: 'about--contrast',
    },
  ],
  hasToUpdateHash: true,
  fromViewportWidth: 1024,
  onInit(immerser) {
    // callback on init
  },
  onBind(immerser) {
    // callback on bind
  },
  onUnbind(immerser) {
    // callback on unbind
  },
  onDestroy(immerser) {
    // callback on destroy
  },
  onActiveLayerChange(activeIndex, immerser) {
    // callback on active layer change
  },
});

// установка иммерсера неправильная
// hasToAdjust false не помогает
